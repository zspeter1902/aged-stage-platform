const btnConfig = [
    {
        code: '65001',
        name: 'excel导出',
        key: 'btn65001'
    }
]
// module.exports = levelConfig
export default btnConfig
