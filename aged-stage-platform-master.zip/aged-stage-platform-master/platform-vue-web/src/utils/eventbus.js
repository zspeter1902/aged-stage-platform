/**
 * Created by penghao on 18/3/21.
 */
import Vue from 'vue';
export default new Vue();