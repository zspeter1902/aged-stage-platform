# platform-vue-web #
## 通用ElementUI
### 概述


### 开发
``` bash
# git clone 

# install dependencies
npm install

# started
npm run dev

# build test
npm run build:sit

# build online
npm run build:prod

```



