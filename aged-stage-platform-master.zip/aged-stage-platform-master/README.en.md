# 基于Java-VUE-SpringBoot-MySQL的养老院管理系统-养老驿站-毕设选题

#### Description
该养老院管理系统适用于养老院、老年公寓、敬老院、托养院等机构，用于提高养老院内部工作效率。主要是针对养老院工作人员即管理员和护工设计的。养老院管理系统将IT技术为养老院提供一个接口便于管理信息,存储老人信息和其他信息,查找和更新信息的养老院档案,节省了员工的劳动时间,大大降低了成本。

#### Software Architecture
Software architecture description

#### Installation

1.  xxxx
2.  xxxx
3.  xxxx

#### Instructions

1.  xxxx
2.  xxxx
3.  xxxx

#### Contribution

1.  Fork the repository
2.  Create Feat_xxx branch
3.  Commit your code
4.  Create Pull Request


#### Gitee Feature

1.  You can use Readme\_XXX.md to support different languages, such as Readme\_en.md, Readme\_zh.md
2.  Gitee blog [blog.gitee.com](https://blog.gitee.com)
3.  Explore open source project [https://gitee.com/explore](https://gitee.com/explore)
4.  The most valuable open source project [GVP](https://gitee.com/gvp)
5.  The manual of Gitee [https://gitee.com/help](https://gitee.com/help)
6.  The most popular members  [https://gitee.com/gitee-stars/](https://gitee.com/gitee-stars/)
